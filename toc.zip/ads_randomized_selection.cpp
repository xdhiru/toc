#include <iostream>

class RandomizedSelection {
private:
    static int random(int low, int high) {
        static unsigned seed = 42;
        seed = seed * 1103515245 + 12345;
        return low + (seed % (high - low + 1));
    }

    static int partition(int arr[], int low, int high) {
        int randomIndex = random(low, high);
        std::swap(arr[randomIndex], arr[high]);
        
        int pivot = arr[high];
        int i = low - 1;
        
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                std::swap(arr[i], arr[j]);
            }
        }
        
        std::swap(arr[i + 1], arr[high]);
        return i + 1;
    }
    
    static int selectRecursive(int arr[], int low, int high, int k) {
        if (low == high) {
            return arr[low];
        }
        
        int pivotIndex = partition(arr, low, high);
        
        int rank = pivotIndex - low + 1;
        
        if (k == rank) {
            return arr[pivotIndex];
        }
        else if (k < rank) {
            return selectRecursive(arr, low, pivotIndex - 1, k);
        }
        else {
            return selectRecursive(arr, pivotIndex + 1, high, k - rank);
        }
    }

public:
    static int select(int arr[], int size, int k) {
        if (k < 1 || k > size) {
            std::cerr << "k is out of range" << std::endl;
            return -1;
        }
        
        return selectRecursive(arr, 0, size - 1, k);
    }
    
    static void printArray(int arr[], int size) {
        for (int i = 0; i < size; i++) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    int arr1[] = {7, 10, 4, 3, 20, 15};
    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    
    int k1 = 3;
    int result1 = RandomizedSelection::select(arr1, size1, k1);
    
    std::cout << "Array: ";
    RandomizedSelection::printArray(arr1, size1);
    std::cout << k1 << "rd smallest element: " << result1 << std::endl;
    
    return 0;
}