#include <iostream>
#include <string>
using namespace std;

void State0(const string &w, int i);
void State1(const string &w, int i);
void State2(const string &w, int i);

int main() {
    string w;
    cout << "Enter a string: ";
    cin >> w;

    // Check the minimum length constraint
    if (w.length() < 2) {
        cout << "String is rejected (length < 2)" << endl;
        return 0;
    }

    State0(w, 0);  // Start the finite automaton from State 0
    return 0;
}

void State0(const string &w, int i) {
    cout << "State 0" << endl;
    if (w[i] == 'a') {
        State1(w, i + 1);  // If 'a', move to State 1
    } else {
        cout << "String is rejected (starts with a character other than 'a')" << endl;
    }
}

void State1(const string &w, int i) {
    cout << "State 1" << endl;
    if (i == w.length() - 1) {
        // If last character is 'b', move to State 2
        if (w[i] == 'b') {
            State2(w, i + 1);
        } else {
            cout << "String is rejected (doesn't end with 'b')" << endl;
        }
    } else {
        // Process middle characters, stay in State 1
        if (w[i] == 'a' || w[i] == 'b') {
            State1(w, i + 1);
        } else {
            cout << "String is rejected (invalid character)" << endl;
        }
    }
}

void State2(const string &w, int i) {
    cout << "State 2" << endl;
    if (i == w.length()) {
        cout << "String is accepted (first character 'a' and last character 'b')" << endl;
    } else {
        cout << "String is rejected (invalid character in the middle)" << endl;
    }
}
