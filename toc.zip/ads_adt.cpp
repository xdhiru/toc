#include <iostream>

class VectorADT {
private:
    static const int MAX_SIZE = 100;
    int data[MAX_SIZE];
    int currentSize;

public:
    VectorADT() : currentSize(0) {}

    void insert(int index, int value) {
        if (index < 0 || index > currentSize || currentSize >= MAX_SIZE) {
            std::cout << "Insert failed" << std::endl;
            return;
        }
        
        for (int i = currentSize; i > index; i--) {
            data[i] = data[i-1];
        }
        
        data[index] = value;
        currentSize++;
    }

    void remove(int index) {
        if (index < 0 || index >= currentSize) {
            std::cout << "Remove failed" << std::endl;
            return;
        }
        
        for (int i = index; i < currentSize - 1; i++) {
            data[i] = data[i+1];
        }
        
        currentSize--;
    }

    int get(int index) {
        if (index < 0 || index >= currentSize) {
            std::cout << "Get failed" << std::endl;
            return -1;
        }
        return data[index];
    }

    int size() {
        return currentSize;
    }
};

class ListADT {
private:
    struct Node {
        int data;
        Node* next;
        Node(int val) : data(val), next(nullptr) {}
    };

    Node* head;
    int listSize;

public:
    ListADT() : head(nullptr), listSize(0) {}

    void append(int value) {
        Node* newNode = new Node(value);
        if (!head) {
            head = newNode;
        } else {
            Node* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = newNode;
        }
        listSize++;
    }

    void remove(int value) {
        if (!head) return;

        if (head->data == value) {
            Node* temp = head;
            head = head->next;
            delete temp;
            listSize--;
            return;
        }

        Node* current = head;
        while (current->next) {
            if (current->next->data == value) {
                Node* temp = current->next;
                current->next = temp->next;
                delete temp;
                listSize--;
                return;
            }
            current = current->next;
        }
    }

    bool find(int value) {
        Node* current = head;
        while (current) {
            if (current->data == value) return true;
            current = current->next;
        }
        return false;
    }

    int size() {
        return listSize;
    }
};

class SequenceADT {
private:
    static const int MAX_SIZE = 100;
    int data[MAX_SIZE];
    int currentSize;

public:
    SequenceADT() : currentSize(0) {}

    void insertBefore(int position, int value) {
        if (position < 0 || position > currentSize || currentSize >= MAX_SIZE) {
            std::cout << "Insert before failed" << std::endl;
            return;
        }
        
        for (int i = currentSize; i > position; i--) {
            data[i] = data[i-1];
        }
        
        data[position] = value;
        currentSize++;
    }

    void insertAfter(int position, int value) {
        if (position < -1 || position >= currentSize || currentSize >= MAX_SIZE) {
            std::cout << "Insert after failed" << std::endl;
            return;
        }
        
        for (int i = currentSize; i > position + 1; i--) {
            data[i] = data[i-1];
        }
        
        data[position + 1] = value;
        currentSize++;
    }

    int first() {
        if (currentSize == 0) {
            std::cout << "Sequence is empty" << std::endl;
            return -1;
        }
        return data[0];
    }

    int last() {
        if (currentSize == 0) {
            std::cout << "Sequence is empty" << std::endl;
            return -1;
        }
        return data[currentSize - 1];
    }

    int at(int position) {
        if (position < 0 || position >= currentSize) {
            std::cout << "Invalid position" << std::endl;
            return -1;
        }
        return data[position];
    }
};

int main() {
    VectorADT vec;
    vec.insert(0, 10);
    vec.insert(1, 20);
    vec.insert(2, 30);
    std::cout << "Vector size: " << vec.size() << std::endl;
    std::cout << "Element at index 1: " << vec.get(1) << std::endl;

    ListADT list;
    list.append(5);
    list.append(10);
    list.append(15);
    std::cout << "List size: " << list.size() << std::endl;
    std::cout << "Is 10 in list? " << (list.find(10) ? "Yes" : "No") << std::endl;

    SequenceADT seq;
    seq.insertBefore(0, 100);
    seq.insertAfter(0, 200);
    seq.insertBefore(1, 150);
    std::cout << "First element: " << seq.first() << std::endl;
    std::cout << "Last element: " << seq.last() << std::endl;

    return 0;
}