#include <iostream>
#include <string>
using namespace std;

// Function prototypes
void State0(const string &w, int i);
void State1(const string &w, int i);
void State2(const string &w, int i);
void State3(const string &w, int i);
void State4(const string &w, int i);

int main() {
    string w;
    cout << "Enter a binary string: ";
    cin >> w;
    State0(w, 0);
    return 0;
}

void State0(const string &w, int i) {
    cout << "State 0" << endl;
    if (i == w.length()) {
        cout << "String is rejected (ending in non-final state)" << endl;
        return;
    }
    if (w[i] == '1') {
        State1(w, i + 1);
    } else if (w[i] == '0') {
        State0(w, i + 1);
    }
}

void State1(const string &w, int i) {
    cout << "State 1" << endl;
    if (i == w.length()) {
        cout << "String is rejected (ending in non-final state)" << endl;
        return;
    }
    if (w[i] == '1') {
        State2(w, i + 1);
    } else if (w[i] == '0') {
        State1(w, i + 1);
    }
}

void State2(const string &w, int i) {
    cout << "State 2" << endl;
    if (i == w.length()) {
        cout << "String is accepted (exactly two 1's)" << endl;
        return;
    }
    if (w[i] == '1') {
        State3(w, i + 1);
    } else if (w[i] == '0') {
        State2(w, i + 1);
    }
}

void State3(const string &w, int i) {
    cout << "State 3" << endl;
    if (i == w.length()) {
        cout << "String is accepted (exactly three 1's)" << endl;
        return;
    }
    if (w[i] == '1') {
        State4(w, i + 1);
    } else if (w[i] == '0') {
        State3(w, i + 1);
    }
}

void State4(const string &w, int i) {
    cout << "State 4" << endl;
    if (i == w.length()) {
        cout << "String is rejected (more than three 1's)" << endl;
        return;
    }
    // Remain in State4 regardless of input
    State4(w, i + 1);
}

// Example Execution
// Input:
// 10101

// Output:
// State 0
// State 1
// State 0
// State 1
// State 2
// State 2
// String is accepted (exactly two 1's)

// Input:
// 11101

// Output:
// State 0
// State 1
// State 2
// State 3
// State 4
// State 4
// String is rejected (more than three 1's)

// Input:
// 111

// Output:
// State 0
// State 1
// State 2
// State 3
// String is accepted (exactly three 1's)