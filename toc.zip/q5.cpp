#include <iostream>
#include <string>
using namespace std;

void State0(const string &w, int i);
void State1(const string &w, int i);
void State2(const string &w, int i);
void State3(const string &w, int i);

int main() {
    string w;
    cout << "Enter a string: ";
    cin >> w;

    // Check the minimum length constraint
    if (w.length() < 1) {
        cout << "String is rejected (length < 1)" << endl;
        return 0;
    }

    State0(w, 0);  // Start the finite automaton from State 0
    return 0;
}

void State0(const string &w, int i) {
    cout << "State 0" << endl;
    if (w[i] == 'a') {
        State1(w, i + 1);  // Transition to State 1
    } else if (w[i] == 'b') {
        State2(w, i + 1);  // Transition to State 2
    } else {
        cout << "String is rejected (invalid character)" << endl;
    }
}

void State1(const string &w, int i) {
    cout << "State 1" << endl;
    if (w[i] == 'a') {
        State0(w, i + 1);  // Transition to State 0
    } else if (w[i] == 'b') {
        State3(w, i + 1);  // Transition to State 3
    } else {
        cout << "String is rejected (invalid character)" << endl;
    }
}

void State2(const string &w, int i) {
    cout << "State 2" << endl;
    if (w[i] == 'a') {
        State3(w, i + 1);  // Transition to State 3
    } else if (w[i] == 'b') {
        State0(w, i + 1);  // Transition to State 0
    } else {
        cout << "String is rejected (invalid character)" << endl;
    }
}

void State3(const string &w, int i) {
    cout << "State 3" << endl;
    if (w[i] == 'a') {
        State2(w, i + 1);  // Transition to State 2
    } else if (w[i] == 'b') {
        State1(w, i + 1);  // Transition to State 1
    } else {
        cout << "String is rejected (invalid character)" << endl;
    }
}