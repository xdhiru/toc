#include <iostream>
#include <string>
#include <vector>

bool simulate_anbncn(const std::string& input) {
    // Validate string format
    if (input.empty()) return false;

    // Count a, b, c occurrences
    int countA = 0, countB = 0, countC = 0;
    
    // First pass: count a's
    while (countA < input.length() && input[countA] == 'a') 
        countA++;
    
    // Second pass: count b's
    int j = countA;
    while (j < input.length() && input[j] == 'b') {
        countB++;
        j++;
    }
    
    // Third pass: count c's
    while (j < input.length() && input[j] == 'c') {
        countC++;
        j++;
    }

    // Validation conditions
    return (countA > 0 && 
            countA == countB && 
            countB == countC && 
            j == input.length());
}

int main() {
    // Test cases
    std::vector<std::string> testCases = {
        "abc",         // Valid
        "aabbcc",      // Valid
        "aaabbbccc",   // Valid
        "aabcc",       // Invalid
        "abbc",        // Invalid
        "",            // Invalid
        "aaa"          // Invalid
    };

    for (const auto& test : testCases) {
        std::cout << "Input: " << test 
                  << " - " 
                  << (simulate_anbncn(test) ? "Accepted" : "Rejected") 
                  << std::endl;
    }

    return 0;
}