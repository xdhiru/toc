#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Function to simulate the PDA
bool simulatePDA(const string &w) {
    stack<char> pdaStack;
    pdaStack.push('Z'); // Push initial stack symbol

    int i = 0;
    while (i < w.length()) {
        char current = w[i];
        if (current == 'a') {
            pdaStack.push('A'); // Push 'A' for each 'a'
        } else if (current == 'b') {
            if (!pdaStack.empty() && pdaStack.top() == 'A') {
                pdaStack.pop(); // Pop 'A' for each 'b'
            } else {
                return false; // Invalid sequence
            }
        } else {
            return false; // Invalid character in input
        }
        i++;
    }

    // Check if the stack is in a valid accept state
    return pdaStack.size() == 1 && pdaStack.top() == 'Z';
}

int main() {
    string w;
    cout << "Enter a string (a^n b^n, n > 0): ";
    cin >> w;

    if (simulatePDA(w)) {
        cout << "String is accepted by the PDA." << endl;
    } else {
        cout << "String is rejected by the PDA." << endl;
    }

    return 0;
}
