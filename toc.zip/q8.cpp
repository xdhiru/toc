#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Function to simulate the PDA
bool simulatePDA(const string &w) {
    stack<char> pdaStack;
    int i = 0;

    // Push phase: Push characters of w onto the stack
    while (i < w.length() && w[i] != 'X') {
        pdaStack.push(w[i]);
        i++;
    }

    // Check for the presence of 'X'
    if (i == w.length() || w[i] != 'X') {
        return false; // Reject if 'X' is missing
    }
    i++; // Move past 'X'

    // Pop phase: Verify w^r by popping the stack
    while (i < w.length()) {
        if (pdaStack.empty() || pdaStack.top() != w[i]) {
            return false; // Reject if the stack doesn't match
        }
        pdaStack.pop();
        i++;
    }

    // Accept if stack is empty and input is fully processed
    return pdaStack.empty();
}

int main() {
    string w;
    cout << "Enter a string (wXw^r): ";
    cin >> w;

    if (simulatePDA(w)) {
        cout << "String is accepted by the PDA." << endl;
    } else {
        cout << "String is rejected by the PDA." << endl;
    }

    return 0;
}
