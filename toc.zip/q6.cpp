#include <iostream>
#include <string>

// Function to check if a string belongs to L1
bool isInL1(const std::string &str) {
    if (str.length() >= 4) {
        // Check if the first two characters are the same as the last two
        return str.substr(0, 2) == str.substr(str.length() - 2);
    }
    return false;
}

// Function to check if a string belongs to L2
bool isInL2(const std::string &str) {
    if (str.length() >= 2 && str[0] == 'a' && str.back() == 'b') {
        // Check that all intermediate characters are either 'a' or 'b'
        for (size_t i = 1; i < str.length() - 1; ++i) {
            if (str[i] != 'a' && str[i] != 'b') {
                return false;
            }
        }
        return true;
    }
    return false;
}

// Function to check if a string belongs to the union of L1 and L2
bool isInUnion(const std::string &str) {
    return isInL1(str) || isInL2(str);
}

// Function to check if a string belongs to the intersection of L1 and L2
bool isInIntersection(const std::string &str) {
    return isInL1(str) && isInL2(str);
}

// Function to check if a string belongs to the concatenation of L1 and L2
bool isInConcatenation(const std::string &str) {
    // Concatenation requires dividing the string into two substrings
    // Check each possible split point
    for (size_t i = 1; i < str.length(); ++i) {
        std::string part1 = str.substr(0, i);
        std::string part2 = str.substr(i);
        if (isInL1(part1) && isInL2(part2)) {
            return true;
        }
    }
    return false;
}

int main() {
    std::string input;
    std::cout << "Enter a string over {a, b}: ";
    std::cin >> input;

    std::cout << "String is in L1: " << (isInL1(input) ? "Yes" : "No") << "\n";
    std::cout << "String is in L2: " << (isInL2(input) ? "Yes" : "No") << "\n";
    std::cout << "String is in Union (L1 U L2): " << (isInUnion(input) ? "Yes" : "No") << "\n";
    std::cout << "String is in Intersection (L1 ∩ L2): " << (isInIntersection(input) ? "Yes" : "No") << "\n";
    std::cout << "String is in Concatenation (L1 L2): " << (isInConcatenation(input) ? "Yes" : "No") << "\n";

    return 0;
}
