#include <iostream>
#include <string>

std::string incrementBinary(std::string input) {
    // Pad with leading zero if needed
    input = '0' + input;
    
    // Traverse from right to left
    for (int i = input.length() - 1; i >= 0; i--) {
        if (input[i] == '0') {
            input[i] = '1';
            break;
        } else if (input[i] == '1') {
            input[i] = '0';
        }
    }
    
    // Remove leading zeros manually
    int leadingZeros = 0;
    while (leadingZeros < input.length() - 1 && input[leadingZeros] == '0') {
        leadingZeros++;
    }
    
    input = input.substr(leadingZeros);
    
    return input.empty() ? "0" : input;
}

int main() {
    const char* testCases[] = {"0", "1", "10", "11", "1010", "1111"};
    int numCases = sizeof(testCases) / sizeof(testCases[0]);

    for (int i = 0; i < numCases; i++) {
        std::string result = incrementBinary(testCases[i]);
        std::cout << testCases[i] << " + 1 = " << result << std::endl;
    }

    return 0;
}