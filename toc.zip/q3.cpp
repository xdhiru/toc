#include <iostream>
#include <string>
using namespace std;

void State0(const string &w, int i, char first1, char first2);
void State1(const string &w, int i, char first1, char first2);
void State2(const string &w, int i, char first1, char first2);
void State3(const string &w, int i, char first1, char first2);

int main() {
    string w;
    cout << "Enter a string: ";
    cin >> w;

    if (w.length() < 4) {
        cout << "String is rejected (length < 4)" << endl;
        return 0;
    }
    
    // Start the process by checking the first two characters
    State0(w, 0, w[0], w[1]);
    
    return 0;
}

void State0(const string &w, int i, char first1, char first2) {
    cout << "State 0" << endl;
    if (i == w.length()) {
        cout << "String is rejected (not long enough to check first and last two characters)" << endl;
        return;
    }
    // Transition to State1 to check the next character
    if (w[i] == 'a') {
        State1(w, i + 1, first1, first2);
    } else if (w[i] == 'b') {
        State1(w, i + 1, first1, first2);
    }
}

void State1(const string &w, int i, char first1, char first2) {
    cout << "State 1" << endl;
    if (i == w.length()) {
        cout << "String is rejected (not long enough to check first and last two characters)" << endl;
        return;
    }
    // Transition to State2 to process the next character
    if (w[i] == 'a') {
        State2(w, i + 1, first1, first2);
    } else if (w[i] == 'b') {
        State2(w, i + 1, first1, first2);
    }
}

void State2(const string &w, int i, char first1, char first2) {
    cout << "State 2" << endl;
    if (i == w.length()) {
        cout << "String is rejected (length < 4)" << endl;
        return;
    }
    // Proceed to State3 only when reaching last two characters
    if (i == w.length() - 2) {
        State3(w, i, first1, first2);  // Compare first and last two characters
    } else {
        // Continue the process for intermediate characters
        if (w[i] == 'a') {
            State2(w, i + 1, first1, first2);
        } else if (w[i] == 'b') {
            State2(w, i + 1, first1, first2);
        }
    }
}

void State3(const string &w, int i, char first1, char first2) {
    cout << "State 3" << endl;
    if (w[i] == first1 && w[i + 1] == first2) {
        cout << "String is accepted (first two characters match last two)" << endl;
    } else {
        cout << "String is rejected (mismatch in first and last two characters)" << endl;
    }
}